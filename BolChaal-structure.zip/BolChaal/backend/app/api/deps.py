"""Shared FastAPI dependencies placeholder."""
